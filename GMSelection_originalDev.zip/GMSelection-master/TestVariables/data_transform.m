clc
clear all
close all

data = dlmread('GMdata_dur.csv');
data(:, 1) = (1 - data(:, 1)).^2;
%data(:, [1, 4, 5, 6]) = log10(data(:, [1, 4, 5, 6]));
% good = data(data(:, end)==1, :);
% bad = data(data(:, end)==0, :);

%% Plot dist
% for i=1:length(data(1, :))-1
%     figure
%     histogram(data(data(:, i)<20, i))
% end

%% Nataf transform
for i=1:length(data(1, :))-1
    %Isoproboba transform
%     if i>=1 %if i>=17
%         mu = mean(log(data(data(:, i)>0, i)));
%         sigma = std(log(data(data(:, i)>0, i)));
%         data(:, i) = (log(data(:, i))-mu)/sigma;
%     end
    
    %Z-scoring
    mu = mean(data(:, i));
    sigma = std(data(:, i));
    data(:, i) = (data(:, i)-mu)/sigma;
end

% for i=1:length(data(1, :))-1
%     figure
%     histogram(data(data(:, i)<20, i))
% end

data = data(not(isinf(data(:, 21))), :);
res = data(:, end);
data = data(:, 1:23);
S = cov(data);
[E, D] = eig(S);
data = E'*data';
D = diag(diag(D).^(-0.5));
data = D*data;
data = data';
data = [data, res];

% for i=1:length(data(1, :))-1
%     figure
%     histogram(data(:, i))
% end

% good = data(data(:, end)==1, :);
% bad = data(data(:, end)==0, :);
% %% Z-score
% for i=1:length(data(1, :))-1
%     y2 = quantile(good(:, i), 0.05);
%     y97 = quantile(good(:, i), 0.95);
%     
%     for j=1:length(data(:, i))
%         if data(j, i)< y2 || data(j, i) > y97
%             data(j, i) = 0;
%         end
%     end
%     
%     %Z-scoring
%     mu = mean(data(:, i));
%     sigma = std(data(:, i));
%     data(:, i) = (data(:, i)-mu)/sigma;
% end


% data = data(not(isnan(sum(data, 2))), :);
good = data(data(:, end)==1, :);
bad = data(data(:, end)==0, :);

%Plot variable spatial dist
% for i=1:length(data(1, :))-3
%     for j=i+1:length(data(1, :))-2
%         for k=j+1:length(data(1, :))-1
%             str_var1 = sprintf('Var %d', i);
%             str_var2 = sprintf('Var %d', j);
%             str_var3 = sprintf('Var %d', k);
%             figure
%             hold on
%             scatter3(good(:, i), good(:, j), good(:, k), 'filled', 'ob')
%             scatter3(bad(:, i), bad(:, j), bad(:, k), 'filled', 'or')
%             xlabel(str_var1)
%             ylabel(str_var2)
%             zlabel(str_var3)
%             grid on
%             hold off
%         end
%     end   
% end

dlmwrite('isoprob_dur.csv', data, 'precision', 9);


%% Log transform


%Compute mean and std


% 
% for i=1:length(data(1, :))-1
%     str_var1 = sprintf('Var %d', i);
%     str_var2 = sprintf('Var %d', j);
%     figure
%     hold on
%     histogram(good(:, i))
%     histogram(bad(:, i))
%      xlabel(str_var1)
% %     ylabel(str_var2)
%     grid on
%     hold off
% end
% 
% 
% for i=1:length(data(1, :))-2
%     for j=i+1:length(data(1, :))-1
%         str_var1 = sprintf('Var %d', i);
%         str_var2 = sprintf('Var %d', j);
%         figure
%         hold on
%         scatter(good(:, i), good(:, j), 'filled', 'ob', 'markerfacealpha', 0.3, 'markeredgealpha', 0.3)
%         scatter(bad(:, i), bad(:, j), 'filled', 'or', 'markerfacealpha', 0.3, 'markeredgealpha', 0.3)
%         xlabel(str_var1)
%         ylabel(str_var2)
%         grid on
%         hold off
%     end   
% end
% % 
% for i=1:length(data(1, :))-3
%     for j=i+1:length(data(1, :))-2
%         for k=j+1:length(data(1, :))-1
%             str_var1 = sprintf('Var %d', i);
%             str_var2 = sprintf('Var %d', j);
%             str_var3 = sprintf('Var %d', k);
%             figure
%             hold on
%             scatter3(good(:, i), good(:, j), good(:, k), 'filled', 'ob')
%             scatter3(bad(:, i), bad(:, j), bad(:, k), 'filled', 'or')
%             xlabel(str_var1)
%             ylabel(str_var2)
%             zlabel(str_var3)
%             grid on
%             hold off
%         end
%     end   
% end