import GMClassifierFx as gmc
import sklearn.metrics as skm
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.distributions.empirical_distribution import ECDF
import csv


#########################################################################
#########################################################################
# User-defined paramters
#########################################################################
#Load data with discrete score
data_path = './data/data_red_red.csv'
n_row_skip = 1
n_col_skip = 3
categoricalOutput = False

#Neural network name
model_name = 'PerfPts'
#########################################################################
#########################################################################

#Load data
data = gmc.loadCSV(data_path, row_ignore=n_row_skip, col_ignore=n_col_skip, isInput=True, isCategorical=categoricalOutput)
y_test = data[1]
data = gmc.preprocessData(data[0])

#Neural Net
NN = gmc.neuralNet()
NN.loadNN(model_name)

y_hat = []

for i in range(len(data)):
    y_hat.append(NN.useNN(data[i]))
    
#Reorganize data
y_hatB = np.asarray(y_hat).T
y_hatB = y_hatB[0][0]
y_hatG = np.asarray(y_hat).T
y_hatG = y_hatG[1]

y_hatG = y_hatG.tolist()
y_hatG = y_hatG[0]

y_hatG = np.asarray(y_hatG)
y_test = np.asarray(y_test)

'''
#######################################################################
#ROC plot
#######################################################################
fpr = dict()
tpr = dict()
roc_auc = dict()

sumG = 0
sumGP = 0
sumB = 0
sumBP = 0
for i  in range(len(y_test)):
    if y_test[i] == 1:
        sumG = sumG+1
    else:
        sumB = sumB+1
    if y_test[i] == 1 and y_hatG[i]>=y_hatB[i]:
        sumGP = sumGP+1
    if y_test[i] == 0 and y_hatG[i]<y_hatB[i]:
        sumBP=sumBP+1

fpr, tpr, _ = skm.roc_curve(y_test, y_hatG)
roc_auc = skm.auc(fpr, tpr)

plt.figure
lw = 2
plt.plot(fpr, tpr, color='darkorange',
         lw=lw, label='ROC curve (area = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.0])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic')
plt.legend(loc="lower right")
plt.show()
#######################################################################
'''
#######################################################################
# Histograms
#######################################################################
str_ttl = 'Score histograms \nper label'

y_c = y_test

s_100 = []
s_075 = []
s_050G = []
s_050B = []
s_025 = []
s_000 = []

for i in range(len(y_hat)):
    if y_c[i] == 1.:
        s_100.append(y_hatG[i])
    elif y_c[i] == .75:
        s_075.append(y_hatG[i])
    elif y_c[i] == .5:
        s_050G.append(y_hatG[i])
        s_050B.append(1.-y_hatB[i])
    elif y_c[i] == .25:
        s_025.append(y_hatG[i])
    elif y_c[i] == 0.:
        s_000.append(y_hatG[i])

fig, axes = plt.subplots(2, 3)

axes[0, 0].hist(s_100, color='grey', edgecolor='k')
axes[0, 0].set_title('1.00')

axes[0, 1].hist(s_075, color='grey', edgecolor='k')
axes[0, 1].set_title('0.75')

axes[1, 2].hist(s_050G, color='grey', edgecolor='k')
axes[1, 2].set_title('0.50')

axes[1, 0].hist(s_000, color='grey', edgecolor='k')
axes[1, 0].set_title('0.00')

axes[1, 1].hist(s_025, color='grey', edgecolor='k')
axes[1, 1].set_title('0.25')

axes[0, 2].text(0, 0.6, str_ttl, fontsize=14)
axes[0, 2].axis('off')

plt.tight_layout()
#######################################################################


#######################################################################
#Empirical CDF
#######################################################################
str_ttl = 'Score CDF \nper label'

e_100 = ECDF(s_100)
e_075 = ECDF(s_075)
e_050 = ECDF(s_050G)
e_025 = ECDF(s_025)
e_000 = ECDF(s_000)

fig, axes = plt.subplots(2, 3)

axes[0, 0].plot(e_100.x, e_100.y, color='k')
axes[0, 0].plot([0., 1.], [0., 1.], color='grey', linestyle=':')
axes[0, 0].grid()
axes[0, 0].set_title('1.00')

axes[0, 1].plot(e_075.x, e_075.y, color='k')
axes[0, 1].plot([0., 1.], [0., 1.], color='grey', linestyle=':')
axes[0, 1].grid()
axes[0, 1].set_title('0.75')

axes[1, 2].plot(e_050.x, e_050.y, color='k')
axes[1, 2].plot([0., 1.], [0., 1.], color='grey', linestyle=':')
axes[1, 2].grid()
axes[1, 2].set_title('0.50')

axes[1, 0].plot(e_000.x, e_000.y, color='k')
axes[1, 0].plot([0., 1.], [0., 1.], color='grey', linestyle=':')
axes[1, 0].grid()
axes[1, 0].set_title('0.00')

axes[1, 1].plot(e_025.x, e_025.y, color='k')
axes[1, 1].plot([0., 1.], [0., 1.], color='grey', linestyle=':')
axes[1, 1].grid()
axes[1, 1].set_title('0.25')

axes[0, 2].text(0, 0.6, str_ttl, fontsize=14)
axes[0, 2].axis('off')

plt.tight_layout()
#######################################################################


#######################################################################
# Save the vector of results
#######################################################################
with open("y_hat.csv", "w") as f:
    writer = csv.writer(f)
    writer.writerows(y_hat)
f.close()
#######################################################################