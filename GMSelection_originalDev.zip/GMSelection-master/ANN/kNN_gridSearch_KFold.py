import keras
from keras.models import Sequential
from keras.layers import Dense, Activation
from sklearn.preprocessing import LabelEncoder
from keras.utils import np_utils
from keras import backend as back
from keras.layers import Dropout
from keras import regularizers
import numpy as np
import statistics as st
import csv
import os
import errno

##################################################################
#ANNHPrmtr: class containing ANN parameters
##################################################################
class ANNHPrmtr:
	def __init__(self, ID, learning_rate, neuronHL1, neuronHL2, optimizer, dropout_rate, activation_fx, batch_size, patience, learning_rate_decay, l1, l2, K):
		self.ID = ID
		self.learning_rate = learning_rate
		self.neuronHL1 = neuronHL1
		self.neuronHL2 = neuronHL2
		self.optimizer = optimizer
		self.dropout_rate = dropout_rate
		self.activation_fx = activation_fx
		self.batch_size = batch_size
		self.patience = patience
		self.K = K
		self.CVResult = -1.0
		self.singleValidResult = []
		self.singleTrainResult = []
		self.n_epoch = []
		self.trainingHistory = []
		self.learning_rate_decay = learning_rate_decay
		self.l2 = l2
		self.l1 = l1
		for i in range(K):
			self.singleValidResult.append(-1.0)
			self.singleTrainResult.append(-1.0)
			self.n_epoch.append(-1)
			self.trainingHistory.append([])

	def setSingleValidResult(self, i, res):
		self.singleValidResult[i] = res

	def setSingleTrainResult(self, i, res):
		self.singleTrainResult[i] = res

	def setSingleNEpoch(self, i, n_epoch):
		self.n_epoch[i] = n_epoch

	def setTrainingHistory(self, i, hist):
		self.trainingHistory[i] = hist

	def computeCVResult(self):
		#Check if CV worked
		validCV = True
		for i in range(self.K):
			if self.singleValidResult[i] == -1:
				print('Cross-validation incomplete or failed\n')
				validCV = False

		#Compute CV
		if validCV:
			self.CVResult = np.sum(self.singleValidResult)/self.K

	def printModel(self):
		str_res = '\n##################################################\nModel ' + str(self.ID) + ':\n\tLearning rate:\t' + str(self.learning_rate) + '\n\tNeuron in HL1:\t' + str(self.neuronHL1) + '\n\tNeuron in HL2:\t' + str(self.neuronHL2) + '\n\tOptimizer:\t' + self.optimizer + '\n\tDropout rate:\t' + str(self.dropout_rate) + '\n\tActivation fx:\t' + self.activation_fx + '\n\tBatch size:\t' + str(self.batch_size)+ '\n\tLearning rate decay:\t' + str(self.learning_rate_decay) + '\n\tL1 regularizer:\t' + str(self.l1) + '\n\tL2 regularizer:\t' + str(self.l2) + '\n\tPatience:\t' + str(self.patience) + '\n--------------------------------------------------\n' + str(self.K) + '-fold cross-validation result:\t' + str(self.CVResult) + '\n##################################################\n'
		print(str_res)

	def saveModelResult(self):
		#Create directory if not already existing
		dir_path = './CVModels/'
		file_path = './CVModels/model_' + str(self.ID) + '.txt'
		if not os.path.exists(dir_path):
			os.mkdir(dir_path)

		#Create the string to save
		#Summary
		str_res = '\n##################################################\nModel ' + str(self.ID) + ':\n\tLearning rate:\t' + str(self.learning_rate) + '\n\tNeuron in HL1:\t' + str(self.neuronHL1) + '\n\tNeuron in HL2:\t' + str(self.neuronHL2) + '\n\tOptimizer:\t' + self.optimizer + '\n\tDropout rate:\t' + str(self.dropout_rate) + '\n\tActivation fx:\t' + self.activation_fx + '\n\tBatch size:\t' + str(self.batch_size)+ '\n\tLearning rate decay:\t' + str(self.learning_rate_decay) + '\n\tL1 regularizer:\t' + str(self.l1) + '\n\tL2 regularizer:\t' + str(self.l2) + '\n\tPatience:\t' + str(self.patience) + '\n--------------------------------------------------\n' + str(self.K) + '-fold cross-validation result:\t' + str(self.CVResult) + '\n##################################################\n\n'
		#Training
		for i in range(self.K):
			str_res = str_res + '--------------------------------------------------\nValidation on folder ' + str(i+1) + ':\n--------------------------------------------------\nEpoch\tTraining loss\tValidation loss\n'
			for j in range(len(self.trainingHistory[i][0])):
				str_res = str_res + str(j) + '\t' + str(self.trainingHistory[i][0][j]) + '\t' + str(self.trainingHistory[i][1][j]) + '\n'
			str_res = str_res + '--------------------------------------------------\n\n'

		#Save the file
		with open(file_path, "w") as output_file:
			print(str_res, file=output_file)
		output_file.close()

	def saveBestModelResult(self, name):
		#Create directory if not already existing
		dir_path = './' + name + '/'
		file_path = dir_path + 'model_' + str(self.ID) + '.txt'
		if not os.path.exists(dir_path):
			os.mkdir(dir_path)

		#Create the string to save
		#Summary
		str_res = '\n##################################################\nModel ' + str(self.ID) + ':\n\tLearning rate:\t' + str(self.learning_rate) + '\n\tNeuron in HL1:\t' + str(self.neuronHL1) + '\n\tNeuron in HL2:\t' + str(self.neuronHL2) + '\n\tOptimizer:\t' + self.optimizer + '\n\tDropout rate:\t' + str(self.dropout_rate) + '\n\tActivation fx:\t' + self.activation_fx + '\n\tBatch size:\t' + str(self.batch_size)+ '\n\tLearning rate decay:\t' + str(self.learning_rate_decay) + '\n\tL1 regularizer:\t' + str(self.l1) + '\n\tL2 regularizer:\t' + str(self.l2) + '\n\tPatience:\t' + str(self.patience) + '\n--------------------------------------------------\n' + str(self.K) + '-fold cross-validation result:\t' + str(self.CVResult) + '\n##################################################\n\n'
		#Training
		for i in range(self.K):
			str_res = str_res + '--------------------------------------------------\nValidation on folder ' + str(i+1) + ':\n--------------------------------------------------\nEpoch\tTraining loss\tValidation loss\n'
			for j in range(len(self.trainingHistory[i][0])):
				str_res = str_res + str(j) + '\t' + str(self.trainingHistory[i][0][j]) + '\t' + str(self.trainingHistory[i][1][j]) + '\n'
			str_res = str_res + '--------------------------------------------------\n\n'


		#Save the file
		with open(file_path, "w") as output_file:
			print(str_res, file=output_file)
		output_file.close()		

	def evaluateModel(self, dataCV, i_K, loss_metric, final_activation, max_epoch, cat_output=False):
		#Input dimension
		dim_input = len(dataCV[0][0][0])

		#Number of outputs
		n_output = -1
		if np.isscalar(dataCV[0][1][0]) and cat_output == False:
			n_output = 1
		else:
			n_output = len(dataCV[0][1][0])

		#Build keras sequential model
		model = Sequential()
		model.add(Dense(self.neuronHL1, input_dim=dim_input, kernel_regularizer=regularizers.l2(self.l2), activity_regularizer=regularizers.l1(self.l1)))
		model.add(Activation(self.activation_fx))
		if self.dropout_rate > 0.0:
			model.add(Dropout(self.dropout_rate))
		if self.neuronHL2 > 0:
			model.add(Dense(self.neuronHL2, kernel_regularizer=regularizers.l2(self.l2), activity_regularizer=regularizers.l1(self.l1)))
			model.add(Activation(self.activation_fx))
			if self.dropout_rate > 0.0:
				model.add(Dropout(self.dropout_rate))
		model.add(Dense(n_output)) 
		model.add(Activation(final_activation))

		#Optimizer setup
		if self.optimizer == 'SGD':
			optimizer_comp = keras.optimizers.SGD(lr=self.learning_rate, momentum=0.0, decay=self.learning_rate_decay, nesterov=False)
		elif self.optimizer == 'Nesterov':
			optimizer_comp = keras.optimizers.SGD(lr=self.learning_rate, momentum=0.0, decay=self.learning_rate_decay, nesterov=True)
		elif self.optimizer == 'RMSprop':
			optimizer_comp = keras.optimizers.RMSprop(lr=self.learning_rate, rho=0.9, decay=self.learning_rate_decay)
		elif self.optimizer == 'Adagrad':
			optimizer_comp = keras.optimizers.Adagrad(lr=self.learning_rate, decay=self.learning_rate_decay)
		elif self.optimizer == 'Adadelta':
			optimizer_comp = keras.optimizers.Adadelta(lr=self.learning_rate, rho=0.95, decay=self.learning_rate_decay)
		elif self.optimizer == 'Adam':
			optimizer_comp = keras.optimizers.Adam(lr=self.learning_rate, beta_1=0.9, beta_2=0.999, decay=self.learning_rate_decay, amsgrad=False)
		elif self.optimizer == 'AMSgrad':
			optimizer_comp = keras.optimizers.Adam(lr=self.learning_rate, beta_1=0.9, beta_2=0.999,decay=self.learning_rate_decay, amsgrad=True)
		elif self.optimizer == 'Adamax':
			optimizer_comp = keras.optimizers.Adamax(lr=self.learning_rate, beta_1=0.9, beta_2=0.999, decay=self.learning_rate_decay)
		elif self.optimizer == 'Nadam':
			optimizer_comp = keras.optimizers.Nadam(lr=self.learning_rate, beta_1=0.9, beta_2=0.999, schedule_decay=self.learning_rate_decay)
		else:
			print('Given optimizer not recognized\nReplaced by Adam\n')

		#Fit
		dataCV[1][1] = np.asarray(dataCV[1][1])
		dataCV[1][0] = np.asarray(dataCV[1][0])
		if cat_output:
			if n_output > 2:
				model.compile(optimizer=optimizer_comp, loss=loss_metric, metrics = ['categorical_accuracy'])
				earlyStopping=keras.callbacks.EarlyStopping(monitor='val_categorical_accuracy', patience=self.patience, verbose=0, mode='auto')
				hist = model.fit(x=np.asarray(dataCV[0][0]), y=np.asarray(dataCV[0][1]), epochs=max_epoch, batch_size=self.batch_size, validation_data=dataCV[1], verbose=0, callbacks=[earlyStopping], shuffle=True)
				self.setSingleValidResult(i_K, hist.history['val_categorical_accuracy'][-1])
				self.setSingleTrainResult(i_K, hist.history['categorical_accuracy'][-1])
				self.setSingleNEpoch(i_K, len(hist.history['categorical_accuracy']))
				self.setTrainingHistory(i_K, [hist.history['categorical_accuracy'], hist.history['val_categorical_accuracy']])
				#Memory release
				back.clear_session()
			else:
				model.compile(optimizer=optimizer_comp, loss=loss_metric, metrics = ['binary_accuracy'])
				earlyStopping=keras.callbacks.EarlyStopping(monitor='val_binary_accuracy', patience=self.patience, verbose=0, mode='auto')
				hist = model.fit(x=np.asarray(dataCV[0][0]), y=np.asarray(dataCV[0][1]), epochs=max_epoch, batch_size=self.batch_size, validation_data=dataCV[1], verbose=0, callbacks=[earlyStopping], shuffle=True)
				self.setSingleValidResult(i_K, hist.history['val_binary_accuracy'][-1])
				self.setSingleTrainResult(i_K, hist.history['binary_accuracy'][-1])
				self.setSingleNEpoch(i_K, len(hist.history['binary_accuracy']))
				self.setTrainingHistory(i_K, [hist.history['binary_accuracy'], hist.history['val_binary_accuracy']])
				#Memory release
				back.clear_session()
		else:
			model.compile(optimizer=optimizer_comp, loss=loss_metric)
			earlyStopping=keras.callbacks.EarlyStopping(monitor='val_loss', patience=self.patience, verbose=0, mode='auto')
			hist = model.fit(x=np.asarray(dataCV[0][0]), y=np.asarray(dataCV[0][1]), epochs=max_epoch, batch_size=self.batch_size, validation_data=dataCV[1], verbose=0, callbacks=[earlyStopping], shuffle=True)
			self.setSingleValidResult(i_K, hist.history['val_loss'][-1])
			self.setSingleTrainResult(i_K, hist.history['loss'][-1])
			self.setSingleNEpoch(i_K, len(hist.history['loss']))
			self.setTrainingHistory(i_K, [hist.history['loss'], hist.history['val_loss']])
			#Memory release
			back.clear_session()


##################################################################
#isNumber: check if a string is a number
##################################################################
def isNumber(s):
	try:
		float(s)
		return True

	except ValueError:
		return False


##################################################################
#loadCSV: load the csv data file
##################################################################
def loadCSV(data_path, row_ignore=0, col_ignore=0, isInput=False, isCategorical=False):
	if not isInput:
		M = []
		with open(data_path) as csvfile:
			readCSV = csv.reader(csvfile)

			#Skip header
			for i in range(row_ignore):
				next(csvfile)

			for row in readCSV:
				#Input vector
				single_line = []
				for i in range(col_ignore, len(row)):
					if isNumber(row[i]):
						single_line.append(float(row[i]))
					else:
						single_line.append(row[i])
				M.append(single_line)

		return M

	#input: last column is the output
	elif isInput:
		v_input = []
		v_output = []

		with open(data_path) as csvfile:
			readCSV = csv.reader(csvfile)

			#Skip header
			for i in range(row_ignore):
				next(csvfile)

			for row in readCSV:
				#Input vector
				single_input = []
				for i in range(col_ignore, len(row)-1):
					single_input.append(float(row[i]))
				v_input.append(single_input)
				if isCategorical == True:
					v_output.append(row[-1])
				else:
					if isNumber(row[-1]):
						v_output.append(float(row[-1]))
					else:
						v_output.append(row[-1])
		csvfile.close()

		if isCategorical:
			#Number of outputs
			n_output = -1

			label = []
			for i in range(len(v_output)):
				if i == 0:
					label.append(v_output[i])
				else:
					isDifferent = True
					for j in range(len(label)):
						if label[j] == v_output[i]:
							isDifferent = False
							break
					if isDifferent:
						label.append(v_output[i])

			n_output = len(label)
	
			#Encode class values as integers
			encoder = LabelEncoder()
			encoder.fit(label)
			encoded_output = encoder.transform(v_output)

			#Convert integers to categorical variables
			catalog_output = np_utils.to_categorical(encoded_output)
			v_output = catalog_output

		return [v_input, v_output]


##################################################################
#getIndicesK: get indices to split the dataset into K folders with almost equal length
##################################################################
def getIndicesK(N, K):
	#Generate random indices < K to create the folders
	ind_K = np.random.randint(0, K, N)

	return ind_K


##################################################################
# createKFold: create K folder of approximately the same size (default size = 10)
##################################################################
def createKFold(data, K=None):
	#Set default value for K if needed
	if K == None:
		K = 10

	#Get the K indices 
	ind_K = getIndicesK(len(data[0]), K)

	#Create the K folders
	inputK = []
	outputK = []
	for i in range(K):
		inputK.append([])
		outputK.append([])

	for i in range(len(data[0])):
		inputK[ind_K[i]].append(data[0][i])
		outputK[ind_K[i]].append(data[1][i])

	return [inputK, outputK]


##################################################################
# createKNNHPrmtr: create the keras NN hyper-parameter objects
##################################################################
def createKNNHPrmtr(gs_path, K):
	#Import csv
	gs_prmtr = loadCSV(gs_path)

	#Create the objects
	ID = -1
	kNNHPrmtr = []
	for lr in range(1, len(gs_prmtr[0])):
		for n1 in range(1, len(gs_prmtr[1])):
			for n2 in range(1, len(gs_prmtr[2])):
				for o in range(1, len(gs_prmtr[3])):
					for d in range(1, len(gs_prmtr[4])):
						for a in range(1, len(gs_prmtr[5])):
							for b in range(1, len(gs_prmtr[6])):
								for p in range(1, len(gs_prmtr[7])):
									for ld in range(1, len(gs_prmtr[8])):
										for r in range(1, len(gs_prmtr[9])):
											for lp in range(1, len(gs_prmtr[10])):
												ID = ID + 1
												kNN_curr = ANNHPrmtr(ID, gs_prmtr[0][lr], 
													int(gs_prmtr[1][n1]), 
													int(gs_prmtr[2][n2]), 
													gs_prmtr[3][o], 
													gs_prmtr[4][d], 
													gs_prmtr[5][a], 
													int(gs_prmtr[6][b]), 
													int(gs_prmtr[7][p]), 
													gs_prmtr[10][lp],
													gs_prmtr[8][ld], 
													gs_prmtr[9][r],
													K)
												kNNHPrmtr.append(kNN_curr)

	#Return hyper-parameter collection
	return kNNHPrmtr


##################################################################
# composeTrainingSet: re-compose the training set based on the index selected for validation
##################################################################
def composeTrainingSet(dataK, i_val):
	input_tr = []
	output_tr = []
	input_val = dataK[0][i_val]
	output_val = dataK[1][i_val]

	for i in range(len(dataK[0])):
		if i != i_val:
			for j in range(len(dataK[0][i])):
				input_tr.append(dataK[0][i][j])
				output_tr.append(dataK[1][i][j])


	return [[input_tr, output_tr], [input_val, output_val]]	


##################################################################
# selectBestmodel: return the best model
##################################################################
def selectBestModel(kNNHPrmtrSet, categorical=False):
	CVResult = []
	for i in range(len(kNNHPrmtrSet)):
		CVResult.append(kNNHPrmtrSet[i].CVResult)

	if categorical:
		i_best = np.argmax(CVResult)
	else:
		i_best = np.argmin(CVResult)

	kNNHPrmtrSet[i_best].printModel()

	return kNNHPrmtrSet[i_best]


##################################################################
# trainBestmodel: train the best model
##################################################################
def trainBestModel(bestModel, data, loss_metric, final_activation, max_epoch, cat_output=False):
	#Input dimension
	dim_input = len(data[0][0])

	#Number of outputs
	n_output = -1
	if np.isscalar(data[1][0]) and cat_output == False:
		n_output = 1
	else:
		n_output = len(data[1][0])

	#Build keras sequential model
	model = Sequential()
	model.add(Dense(bestModel.neuronHL1, input_dim=dim_input, activity_regularizer=regularizers.l2(bestModel.l2)))
	model.add(Activation(bestModel.activation_fx))
	if bestModel.dropout_rate > 0.0:
		model.add(Dropout(bestModel.dropout_rate))
	if bestModel.neuronHL2 > 0:
		model.add(Dense(bestModel.neuronHL2, activity_regularizer=regularizers.l2(bestModel.l2)))
		model.add(Activation(bestModel.activation_fx))
		if bestModel.dropout_rate > 0.0:
			model.add(Dropout(bestModel.dropout_rate))
	model.add(Dense(n_output)) 
	model.add(Activation(final_activation))

	#Optimizer setup
	if bestModel.optimizer == 'SGD':
		optimizer_comp = keras.optimizers.SGD(lr=bestModel.learning_rate, momentum=0.0, decay=bestModel.learning_rate_decay, nesterov=False)
	elif bestModel.optimizer == 'Nesterov':
		optimizer_comp = keras.optimizers.SGD(lr=bestModel.learning_rate, momentum=0.0, decay=bestModel.learning_rate_decay, nesterov=True)
	elif bestModel.optimizer == 'RMSprop':
		optimizer_comp = keras.optimizers.RMSprop(lr=bestModel.learning_rate, rho=0.9, decay=bestModel.learning_rate_decay)
	elif bestModel.optimizer == 'Adagrad':
		optimizer_comp = keras.optimizers.Adagrad(lr=bestModel.learning_rate, epsilon=None, decay=bestModel.learning_rate_decay)
	elif bestModel.optimizer == 'Adadelta':
		optimizer_comp = keras.optimizers.Adadelta(lr=bestModel.learning_rate, rho=0.95, decay=bestModel.learning_rate_decay)
	elif bestModel.optimizer == 'Adam':
		optimizer_comp = keras.optimizers.Adam(lr=bestModel.learning_rate, beta_1=0.9, beta_2=0.999, decay=bestModel.learning_rate_decay, amsgrad=False)
	elif bestModel.optimizer == 'AMSgrad':
		optimizer_comp = keras.optimizers.Adam(lr=bestModel.learning_rate, beta_1=0.9, beta_2=0.999,decay=bestModel.learning_rate_decay, amsgrad=True)
	elif bestModel.optimizer == 'Adamax':
		optimizer_comp = keras.optimizers.Adamax(lr=bestModel.learning_rate, beta_1=0.9, beta_2=0.999, decay=bestModel.learning_rate_decay)
	elif bestModel.optimizer == 'Nadam':
		optimizer_comp = keras.optimizers.Nadam(lr=bestModel.learning_rate, beta_1=0.9, beta_2=0.999, schedule_decay=bestModel.learning_rate_decay)
	else:
		print('Given optimizer not recognized\nReplaced by Adam\n')
		optimizer_comp = keras.optimizers.Adam(lr=bestModel.learning_rate, beta_1=0.9, beta_2=0.999, decay=bestModel.learning_rate_decay, amsgrad=False)

	#Fit
	data[0] = np.asarray(data[0])
	data[1] = np.asarray(data[1])
	if cat_output:
		if n_output > 2:
			model.compile(optimizer=optimizer_comp, loss=loss_metric, metrics = ['categorical_accuracy'])
			earlyStopping=keras.callbacks.EarlyStopping(monitor='categorical_accuracy', patience=bestModel.patience, verbose=0, mode='auto')
			hist = model.fit(x=data[0], y=data[1], epochs=max_epoch, batch_size=bestModel.batch_size, verbose=0, callbacks=[earlyStopping], shuffle=True)
		else:
			model.compile(optimizer=optimizer_comp, loss=loss_metric, metrics = ['binary_accuracy'])
			earlyStopping=keras.callbacks.EarlyStopping(monitor='binary_accuracy', patience=bestModel.patience, verbose=0, mode='auto')
			hist = model.fit(x=data[0], y=data[1], epochs=max_epoch, batch_size=bestModel.batch_size, verbose=0, callbacks=[earlyStopping], shuffle=True)

	else:
		model.compile(optimizer=optimizer_comp, loss=loss_metric)
		earlyStopping=keras.callbacks.EarlyStopping(monitor='loss', patience=bestModel.patience, verbose=0, mode='auto')
		hist = model.fit(x=data[0], y=data[1], epochs=max_epoch, batch_size=bestModel.batch_size, verbose=0, callbacks=[earlyStopping], shuffle=True)

	return [model, hist]


##################################################################
# exportWeights: Save the trained weight of a keras model
##################################################################
def exportWeights(model, name):
	#Get the weights
	w = model.get_weights()

	#Create directory if not already existing
	dir_path = './' + name
	if not os.path.exists(dir_path):
		os.mkdir(dir_path)

	#Create master file (number of hidden layer and activation functions)
	masterF_path = dir_path + '/masterF.txt'
	model_conf = model.get_config()
	n_H = int(len(model_conf)/2-1)
	
	N_input = model_conf[0]['config']['batch_input_shape'][1]
	N_neuronH1 = model_conf[0]['config']['units']
	activation_H1 = model_conf[1]['config']['activation']
	if n_H == 2:
		N_neuronH2 = model_conf[2]['config']['units']
		activation_H2 = model_conf[3]['config']['activation']
		N_output = model_conf[4]['config']['units']
		activation_output = model_conf[5]['config']['activation']
		str_MF = str(N_input) + ',' + str(N_neuronH1) + ',' + str(activation_H1) + ',' + str(N_neuronH2) + ',' + str(activation_H2) + ',' + str(N_output) + ',' + str(activation_output)
	elif n_H == 1:
		N_output = model_conf[2]['config']['units']
		activation_output = model_conf[3]['config']['activation']
		str_MF = str(N_input) + ',' + str(N_neuronH1) + ',' + str(activation_H1) + ',' + str(N_output) + ',' + str(activation_output)
	
	with open(masterF_path, "w") as output_file:
		print(str_MF, file=output_file)
	output_file.close()

	#Create .csv for each layer
	model_weights = model.get_weights()
	
	for i in range(n_H):
		bias_path = dir_path + '/bias_' + str(i+1) + '.csv'
		weight_path = dir_path + '/weight_' + str(i+1) + '.csv'
		with open(bias_path, "w") as output_file:
			writer = csv.writer(output_file)
			writer.writerow(model_weights[2*i+1].tolist())
		output_file.close()
		with open(weight_path, "w") as output_file:
			writer = csv.writer(output_file)
			writer.writerows(model_weights[2*i].tolist())
		output_file.close()

	bias_path = dir_path + '/bias_output.csv'
	weight_path = dir_path + '/weight_output.csv'
	with open(bias_path, "w") as output_file:
		writer = csv.writer(output_file)
		writer.writerow(model_weights[-1].tolist())
	output_file.close()
	with open(weight_path, "w") as output_file:
		writer = csv.writer(output_file)
		writer.writerows(model_weights[-2].tolist())
	output_file.close()
	





































