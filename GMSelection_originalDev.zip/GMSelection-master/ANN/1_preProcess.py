import csv
from matplotlib import rc
from matplotlib import pyplot as plt
import numpy as np
from scipy import stats
import GMClassifierFx as gmc

#For plotting purposes (transform cm to inch)
def cm2inch(value):
	return value/2.54

#Compute the square root of a matrix
def msqrt(X):
    (L, V) = np.linalg.eig(X)
    return V.dot(np.diag(np.sqrt(L))).dot(V.T) 

#########################################################################
#########################################################################
# User-defined paramters
#########################################################################
data_location = './data/data_red_red.csv'
n_row_skip = 1
n_col_skip = 3
categoricalOutput = False
#########################################################################
#########################################################################

#Import data for training and validation
M_input = []
M = gmc.loadCSV(data_location, row_ignore=n_row_skip, col_ignore=n_col_skip, isInput=True, isCategorical=categoricalOutput)

#Separate output from input
M_input = M[0]
M_y = M[1]

#Isolate perfect-quality records
#Main assumption: perfect quality records share some common features and have a different distribution than bad recards
var_g = []
for i in range(len(M_input)):
    if M_y[i] == 1.0:
        var_g.append(M_input[i])

var_g = np.asarray(var_g).T

#Normalize and standardize using a Tukey ladder
mean_v = []
std_v = []
for i in range(20):
    #########################################################################
    #########################################################################
    # User-defined Tukkey ladder (deskew the data)
    #########################################################################
    if i == 0 or i == 1 or i == 11 or i == 15 or i == 16:  
        var_g[i] = [np.log(x) for x in var_g[i]]
    elif i == 17:
        var_g[i] = [-1.0/x**1.2 for x in var_g[i]]
    elif i == 2:
        var_g[i] = [x**(-.2) for x in var_g[i]]
    elif i == 10:
        var_g[i] = [x**(-.06) for x in var_g[i]]
    elif i == 19:
        var_g[i] = [x**.43 for x in var_g[i]]
    elif i == 7:
        var_g[i] = [x**.25 for x in var_g[i]]
    elif i == 8:
        var_g[i] = [x**.23 for x in var_g[i]]
    elif i == 9:
        var_g[i] = [x**.05 for x in var_g[i]]
    elif i == 18:
        var_g[i] = [x**.33 for x in var_g[i]]
    elif i == 3:
        var_g[i] = [x**(.12) for x in var_g[i]]
    elif i == 5:
        var_g[i] = [x**(.48) for x in var_g[i]]
    elif i == 6:
        var_g[i] = [x**(.37) for x in var_g[i]]
    elif i == 12:
        var_g[i] = [x**.05 for x in var_g[i]]
    elif i == 13:
        var_g[i] = [x**.08 for x in var_g[i]]
    elif i == 4:
        var_g[i] = [x**(.16) for x in var_g[i]]
    elif i == 14:
        var_g[i] = [x**(.1) for x in var_g[i]]
    #########################################################################
    #########################################################################
    
    #Compute mean and standard deviation of deskewed data (for standardization)
    mean_v.append(np.mean(var_g[i]))
    std_v.append(np.std(var_g[i]))
    var_g[i] = [(x-mean_v[i])/std_v[i] for x in var_g[i]]
    
    #QQ plot of each deskewed and standardized variable (for validity checking)
    plt.rcParams["font.family"] = "serif"
    
    fig, (ax1) = plt.subplots(1, 1)
    fig.set_size_inches(cm2inch(6), cm2inch(6))
    qq = stats.probplot(var_g[i], plot=ax1)
    ax1.get_lines()[0].set_markerfacecolor([0.5, 0.5, 0.5])
    ax1.get_lines()[0].set_markeredgecolor([0.5, 0.5, 0.5])
    ax1.get_lines()[1].set_color('k')
    ax1.plot([-2, -2], [-4, 4], ':k')
    ax1.plot([2, 2], [-4, 4], ':k')
    ax1.plot([-4, 4], [2, 2], ':k')
    ax1.plot([-4, 4], [-2, -2], ':k')
    ax1.set_ylim([-4, 4])
    ax1.set_xlim([-4, 4])
    ax1.fill_betweenx([-4, 4], 2, -2, facecolor='grey', alpha=0.15)
    ax1.fill_betweenx([-2, 2], 4, -4, facecolor='grey', alpha=0.15)
    ax1.set_title('')
    
    fig.subplots_adjust()
    
    str_fig = './fig/QQvar_' + str(i) + '.pdf'
    fig.savefig(str_fig, dpi=600)
    plt.close()
    
#Compute Mahanalobis decorrelation matrix
S = np.cov(var_g)
S_prime = np.linalg.inv(S)
M = msqrt(S_prime)

#Export Mahalanobis matrix
with open("M.csv", "w") as f:
    writer = csv.writer(f)
    writer.writerows(M)
f.close()

#Export mean and std
T = [mean_v , std_v]
with open("mu_sigma.csv", "w") as f:
    writer = csv.writer(f)
    writer.writerows(T)
f.close()



