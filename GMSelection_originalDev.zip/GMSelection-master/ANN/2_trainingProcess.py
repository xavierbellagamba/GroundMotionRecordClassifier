import kNN_gridSearch_KFold as knn
import GMClassifierFx as gmc

#########################################################################
#########################################################################
# User-defined paramters
#########################################################################
#Path of grid search file and data file
data_path = './data/data_red_red_step.csv'
n_row_skip = 1
n_col_skip = 3
categoricalOutput = True
gs_path = './gridSearch/gs.csv'
K = 2
model_name = 'TestX'
#########################################################################
#########################################################################

#Load the data to fit
data = knn.loadCSV(data_path, row_ignore=1, col_ignore=3, isInput=True, isCategorical=categoricalOutput)

#Standardize and decorrelate data
data[0] = gmc.preprocessData(data[0])

#Creation of the K-Fold
dataK = knn.createKFold(data, K)

#Create the hyper-paramter containers
HP_container = knn.createKNNHPrmtr(gs_path, K)

#Realize the K-Fold CV
for i in range(K):
    dataCV = knn.composeTrainingSet(dataK, i)
    
    for j in range(len(HP_container)):
        #Evaluate model j with validation set i 
        HP_container[j].evaluateModel(dataCV, i, 'binary_crossentropy', 'sigmoid', 500, cat_output=categoricalOutput)
        print('K-Fold:\t' + str(i) + '\tModel:\t' + str(j) + '\tResult:\t' + str(HP_container[j].singleValidResult[i]))

#Evaluate CV errors
for i in range(len(HP_container)):
    HP_container[i].computeCVResult()
    HP_container[i].saveModelResult()

#Select best model
bestHPSet = knn.selectBestModel(HP_container, categorical=categoricalOutput)
bestHPSet.saveBestModelResult(model_name)

#Train best model
[bestModel, hist] = knn.trainBestModel(bestHPSet, data, 'binary_crossentropy', 'sigmoid', 500, cat_output=categoricalOutput)

#Save best model
knn.exportWeights(bestModel, model_name)