clc 
close all
clear all

T = readtable('data_red_red.csv');

T1 = T(T.Quality_score == 1, :);
T2 = T(T.Quality_score == 0, :);

T3 = [T1 ; T2];

writetable(T3, 'data_red_red_perfect.csv', 'delimiter', ';');
