import keras
from keras.models import Sequential
from keras.layers import Dense, Activation
import csv
from matplotlib import rc
from matplotlib import pyplot as plt
import numpy as np
import random
import kNN_gridSearch_KFold as knn

#For plotting purposes (transform cm to inch)
def cm2inch(value):
	return value/2.54

M_input = []
var = [[] for i in range(22)]
M_y = []

#Import data fr training and validation
with open('data_c.csv') as csvfile:
    readCSV = csv.reader(csvfile, delimiter=',')

    for row in readCSV:
        row_input = []
        for i in range(len(row)-1):
            row_input.append(float(row[i]))
            var[i].append(float(row[i]))

        M_input.append(row_input)
        M_y.append([row[-1]])

csvfile.close()


M_input_perfect = []
M_target_perfect = []
count = 0
for i in range(len(M_y)):
    if M_y[i][0] == '1' or M_y[i][0] == '0':
        M_input_perfect.append(M_input[i])
        M_target_perfect.append(M_y[i])
        if M_y[i][0] == '1':
            count = count + 1



'''
#Shuffle imported data
M_y_shuf = []
M_input_shuf = []
index_shuf = np.arange(len(M_y))
index_shuf = index_shuf.tolist()
random.shuffle(index_shuf)
for i in index_shuf:
    M_y_shuf.append(M_y[i])
    M_input_shuf.append(M_input[i])
'''


'''
#Model creation given selected criteria
model = Sequential([
    Dense(100, input_dim=136),
    Activation('tanh'),
    Dense(100),
    Activation('tanh'),
    Dense(100),
    Activation('tanh'),
    Dense(100),
    Activation('tanh'),
    Dense(1), 
    Activation('linear')
])

model.compile(optimizer='adamax',
              loss='mse')

earlyStopping=keras.callbacks.EarlyStopping(monitor='val_loss', patience=50, verbose=0, mode='auto')
hist = model.fit(x=M_input_shuf, y=M_y_shuf, epochs=1500, batch_size=10, validation_split=.4, verbose=2, callbacks=[earlyStopping], shuffle=True)

'''