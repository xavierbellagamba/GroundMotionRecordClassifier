GM Classifier: training and use
_______________________________

Author: X. Bellagamba
25.05.2018

1. Requirements
2. Composition
3. Training process
4. Use trained neural network

##############################################
1. Requirements
##############################################

- Python 3.x
- Tensorflow
- keras
- scikit-learn*
- numpy*
- csv*

*: already present in anaconda environment


##############################################
2. Composition
##############################################

2 packages:
	A. GMClassifierFx.py (used in both the training process and the use process)
	B. kNN_gridSearch_KFold.py (used only in the training process)

3 scripts:
	A. 1_preProcess.py (produces necessary data to standardize and decorrelate the input data)
	B. 2_trainingProcess.py (create and save a cross-validated neural network based on a predifined, user-defeined hyperparameter search grid)
	C. 3_postProcess.py (use the neural network and can produce ROC, histograms and cumulative distribution function plots)

Note: All the user-defined variables or statements are indicated by double lines of *****


##############################################
3. Training process
##############################################

0. In a nutshell
	1. Test deskewing functions by iteratively running the script.
	2. Once deskewing functions are judged acceptable by the user, the script will save the decorrelation matrix and the standardization vectors to the root folders
	3. Run the training process script by specifying the location of the grid, the location of the data, and the number of K subsets. The best model will be saved in a folder of user-defined name.
	4. Run the post-processing script by specifying the name of the neural network and the location of the data. 

1. Pre-processing script
	1. Provide data (with continuous scoring) location and specify number of row and column to be ignored by the importation fx, between lines 17 and 26.
	2. Define if target (y) is categorical or not. (In the present case, it isn't as we want to isolate only perfect records. Hence, always set to False)
	3. Test the distribution of the variables with the current deskewing fx provided between lines 48 and 85. 
	4. If deskewing fx has to be changed, for efficiency purposes, I recommend copy-paste of the plot within the if...elif statement of the varaible to be adapted. 
		Important: Deskewing fx have to be adapted in the GMClassifierFx.py file, currently between lines 90 and 121. I recommend opning this file with gedit for indent-conststency reasons. 
	5. Once deskewing fx are acceptable, let the script finish. It will produce the decorrelation matrix and a 2D vector of main and std that will be used to pre-process the training. 

	Note: The current implementation forces you to let the decorrelation matrix and the 2D vector in the root folder. Feel free to alter this if you wish.

2. Training process script
	1. Provide data (with discrete scoring - only 0 or 1) location and specify number of row and column to be ignored by the importation fx, between lines 4 and 17.
	2. Define if target (y) is categorical or not. (In the present case, it isn't as we want to binary classification. Hence, always set to True)
	3. Provide the path to the grid search csv file. 
		If parameters of the grid search have to be changed, follow the next recommendations:
			a. Open the file with gedit or nano and not exel-type software (it does not understand irregular tables)
			b. Respect the format, order and the number of given parameters. There should be 11 in the following order:
				1. learning_rate
				2. neuronHL1
				3. neuronHL2
				4. optimizer
				5. dropout
				6. activation
				7. batch_size
				8. patience
				9. learning_rate_decay
				10. l2
				11. l1
			c. Separate the values to be tested for each variable with a ','. Example: learning_rate,0.1,0.01,0.05
	4. Give the number of K-fold to be created (typical values5 or 10, recommended: 5)
	5. Give the model name
	6. Run the script. It will take a while (tensorflow is parallel by default, no need to do anything to try to optimize this).
	7. It will create 1 folder containing the 1 text file per tested configuration and 1 folder containing the trained neural network. 
		The text files contain: the model configuration, the cross-validated error, and the evolution of the error over the training for each K-Fold.
		The trained network is given as multiple csv files that must not be altered as well as the text file of the selected configuration.

3. Post-processing script
	Important: current ROC plot works only with discrete scring, whereas histograms and CDF works only with continuous scoring. Feel free to modify this.

	1. Provide data (with continuous or discrete scoring) location and specify number of row and column to be ignored by the importation fx, between lines 13 and 17.
	2. Define if target (y) is categorical or not. (In the present case, it isn't as we want to isolate only perfect records. Hence, always set to False)
	3. Provide name of network to be imported
	
	Note: figures are not automatically saved.


##############################################
4. Use trained neural network
##############################################
The following packages must be install on the host machine:
	1. csv
	2. numpy

Command:
###################

import GMClassifierFx as gmc

#Load unlabeled data (no label column!), where each line represents one ground motion record
data = gmc.loadCSV(data_path, row_ignore=1, col_ignore=3, isInput=False, isCategorical=False)

#Pre-process the data (deskew, decorrelate, and standardize)
data = gmc.preprocessData(data)

#Create an instance of neural network class
NN = gmc.neuralNet()

#Load the neural network
NN.loadNN(model_name)

#Initialize list of score
y_hat = []

#Compute scores
#Data must be arranged in the same way the 
for i in range(len(data)):
    y_hat.append(NN.useNN(data[i]))

####################

Note that we may want to check the dictionary (the algorithm might have assigned the value 1 to bad records and 0 to good)























