clc
close all
clear all

% Import data
data = dlmread('./data/data.csv');

threshold = [0.5, 0.6, 0.7, 0.8, 0.9, 0.95];
result = [];
ratio = [];

for j=1:length(threshold)
    count_10_g = 0;
    count_07_g = 0;
    count_05_g = 0;
    count_02_g = 0;
    count_00_g = 0;

    count_10 = 0;
    count_07 = 0;
    count_05 = 0;
    count_02 = 0;
    count_00 = 0;
    
    for i=1:length(data(:, 1))
        if data(i, 2) > 0.9 && data(i, 4) > threshold(j)
            count_10_g = count_10_g + 1;
        elseif data(i, 2) > 0.7 && data(i, 4) > threshold(j)
            count_07_g = count_07_g + 1;
        elseif data(i, 2) > 0.4 && data(i, 4) > threshold(j)
            count_05_g = count_05_g + 1;
        elseif data(i, 2) > 0.2 && data(i, 4) > threshold(j)
            count_02_g = count_02_g + 1;
        elseif data(i, 2) < 0.1 && data(i, 4) > threshold(j)
            count_00_g = count_00_g + 1;
        end
        
        if data(i, 2) > 0.9 
            count_10 = count_10 + 1;
        elseif data(i, 2) > 0.7 
            count_07 = count_07 + 1;
        elseif data(i, 2) > 0.4 
            count_05 = count_05 + 1;
        elseif data(i, 2) > 0.2
            count_02 = count_02 + 1;
        elseif data(i, 2) < 0.1
            count_00 = count_00 + 1;
        end
    end
    result(j, :) = [count_10_g, count_07_g, count_05_g, count_02_g, count_00_g];
    ratio(j, :) = [count_10_g/count_10, count_07_g/count_07, count_05_g/count_05, count_02_g/count_02, count_00_g/count_00].*100;
end

figure
hold on
bar(result')
grid on
title('Number of accepted GMs given threshold and manual score')
legend('0.5', '0.6', '0.7', '0.8', '0.9', '0.95', 'location', 'northeast')
xticks(0:6)
xticklabels({'', '1.0', '0.75', '0.5', '0.25', '0.0', ''})
box on
hold off

figure
hold on
bar(ratio')
grid on
title('Portion of accepted GMs given threshold and manual score')
legend('0.5', '0.6', '0.7', '0.8', '0.9', '0.95', 'location', 'northeast')
xticks(0:6)
xticklabels({'', '1.0', '0.75', '0.5', '0.25', '0.0', ''})
box on
hold off
