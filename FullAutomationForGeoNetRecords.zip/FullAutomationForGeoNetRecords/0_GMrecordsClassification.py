import os
import numpy as np
import glob
from time import time
from scipy.signal import detrend
from geoNet_file import GeoNet_File
from snrutils import getClassificationMetrics, getClassificationMetrics_loadBestKO, createKonnoMatrices, adjust_gf_for_time_delay
from shutil import copyfile
import matplotlib.pyplot as plt
import pandas as pd

######################################################
#Final products: 
#    Folder of selected GMs
#    Summary pie plot of selected/discarded GMs
#    Summary pie plot of the reasons for discarding
#    Plots of the GM records, Fourier spectra, ...
######################################################

#This process ca still be optimized by using MPI to parallelly assess GMR

#########################################################################
################ USER-DEFINED PARAMETERS ################################
#########################################################################

#Folder of records to assess (selected GMR stored in HQ_GMR_folder_name)
folder_name = 'records'

#Record file extension
ext = 'V1A'

#Plot active (plot the GM record, its Fourier spectrum, ...)
plot_active = False

#Model. Available:
# GMClassifier_CantWell
# GMClassifier_Cant
model = 'GMClassifier_CantWell'

#Acceptance threshold
acceptance_threshold = 0.5

#Computer has more than 16GB of RAM (can be lowered to 13GB)
#Requires to import all Konno Ohmachi matrices at once for faster processing
#0: has not 16GB (if selected, KO matrices must be stored as in lines 77-82)
#1: has 16GB and load matrices
#2: has 16GB and compute matrices
RAM_16 = 0

#########################################################################
#########################################################################

#set initiation timer
init_time=time()

#Import user-defined classifier
if model == 'GMClassifier_CantWell':
    import GMClassifier_CantWell.GMClassifierFx as GMC
elif model == 'GMClassifier_Cant':
    import GMClassifier_Cant.GMClassifierFx as GMC

#Load neural Net
NN = GMC.neuralNet()
NN.loadNN(model+'/'+model)

#Create list of files to treat
pattern = './' + folder_name + '/*.' + ext
file_list = glob.glob(pattern)

#Create result folder
final_folder = 'HQ_GMR_'+folder_name
try:
    os.mkdir('HQ_GMR_'+folder_name)
except:
    print('Folder already exists')

#Create plot results
if plot_active:
    try:
        os.mkdir('plots')
    except:
        print('Folder already exists')
        
#Pre-load KO matrices if computer has more than 16GB of RAM
if RAM_16 == 2:
    konno1024, konno2048, konno4096, konno8192, konno16384, konno32768 = createKonnoMatrices()
elif RAM_16 == 1: 
    konno1024 = np.load('./KO_matrices/KO_1024.npy')
    konno2048 = np.load('./KO_matrices/KO_2048.npy')
    konno4096 = np.load('./KO_matrices/KO_4096.npy')
    konno8192 = np.load('./KO_matrices/KO_8192.npy')
    konno16384 = np.load('./KO_matrices/KO_16384.npy')
    konno32768 = np.load('./KO_matrices/KO_32768.npy')

#Meta data results
meta_data_result = []

#Treat each GM in the list
for file in file_list:
    #set up flags
    flagErr = 1 #Error
    flagM = 1 #Malfunction
    GM_score = np.asarray([-1, -1])
    isSelected = 0
    
    #initialize lists for quality metric data
    obsgm_metadata = []
    mf_metadata = []
    
    #Spec record
    stat_code = file.split('/')[2].split('.')[0]

    #extract data from geonet file (format is specific to geonet)
    gf = GeoNet_File(file, os.getcwd(), vol=1)
    
    #check that record is more than 5 seconds
    if gf.comp_1st.acc.size < 5./gf.comp_1st.delta_t:
        flagErr = 0

    #When appended zeroes at the beginning of the record are removed, the 
    #record might then be empty, skipp processing in such a case
    agf=adjust_gf_for_time_delay(gf)
    if agf.comp_1st.acc.size <= 10:
        #less than 10 elements between earthquake rupture origin time and end of record
        flagErr = 0
        
    #quick and simple (not the best) baseline correction with demean and detrend
    gf.comp_1st.acc -= gf.comp_1st.acc.mean()
    gf.comp_2nd.acc -= gf.comp_2nd.acc.mean()
    gf.comp_up.acc  -= gf.comp_up.acc.mean()

    gf.comp_1st.acc = detrend(gf.comp_1st.acc, type='linear')
    gf.comp_2nd.acc = detrend(gf.comp_2nd.acc, type='linear')
    gf.comp_up.acc = detrend(gf.comp_up.acc, type='linear')

    #pass in record to get quality classification metrics
    if RAM_16 == 0:
        p_pick, s_pick, snr_min, snr_max, snr_average, signal_ratio_max, signal_pe_ratio_max, \
        tail_ratio, mtail_ratio, tailnoise_ratio, mtailnoise_ratio, head_ratio, fmin, \
        snr_a1, snr_a2, snr_a3, snr_a4, snr_a5, ft_a1, ft_a2, ft_a1_a2, ft_s1, ft_s2, ft_s1_s2, \
        PGA, PN, PNPGA, Arias, bracketedPGA_10_20, Ds575, Ds595, zeroc = \
        getClassificationMetrics_loadBestKO(os.path.join('./plots/' + stat_code + '.png'), os.path.join(stat_code + '.fas'), \
                                            gf, stat_code, 80, 400, plot_active)
    elif RAM_16 > 0:
        p_pick, s_pick, snr_min, snr_max, snr_average, signal_ratio_max, signal_pe_ratio_max, \
        tail_ratio, mtail_ratio, tailnoise_ratio, mtailnoise_ratio, head_ratio, fmin, \
        snr_a1, snr_a2, snr_a3, snr_a4, snr_a5, ft_a1, ft_a2, ft_a1_a2, ft_s1, ft_s2, ft_s1_s2, \
        PGA, PN, PNPGA, Arias, bracketedPGA_10_20, Ds575, Ds595, zeroc = \
        getClassificationMetrics(os.path.join('./plots/' + stat_code + '.png'), os.path.join(stat_code + '.fas'), \
                                 gf, stat_code, 80, 400, konno1024, konno2048, konno4096, konno8192, konno16384, konno32768, plot_active)

    #number of zero crossings per 10 seconds less than 10 equals malfunctioned record
    if zeroc < 10:
        flagM = 0

    #write the quality metrics to file depending on whether it is considered a malfunctioned record or not
    if flagM == 1: 
        quality_metrics = [signal_pe_ratio_max, signal_ratio_max, \
                               snr_min, snr_max, snr_average, tail_ratio, mtail_ratio, tailnoise_ratio, \
                               mtailnoise_ratio, head_ratio, snr_a1, snr_a2, snr_a3, snr_a4, snr_a5, \
                               ft_a1_a2, PNPGA, bracketedPGA_10_20, Ds575, Ds595]
        
        #Pre-process qualtiy metrics
        pp_data = GMC.preprocessData([quality_metrics])
    
        #Assess the GM quality
        GM_score = NN.useNN(pp_data[0])
    
        #Copy/paste GM record (V1A file) if quality high enough
        if GM_score[0][1] >= acceptance_threshold:
            dest = './' + final_folder + '/' + file.split('/')[2]
            copyfile(file, dest)
            isSelected = 1
            
    meta_data_result.append([stat_code, GM_score[0][1], GM_score[0][0], flagM, flagErr, isSelected])

#save meta data results
hd = ['Name', 'Score_HQ', 'Score_LQ', 'Malfunct', '5sec', 'Selected']
data = pd.DataFrame(meta_data_result, columns=hd)
data.to_csv('meta_data_results.csv')
#np.savetxt(os.path.join(os.getcwd(),), meta_data_result, fmt='%s', delimiter=',', newline='\n')

#Plot summary
n_select = np.sum(data['Selected'] == 1)
n_refuse = np.sum(data['Selected'] == 0)
p_select = n_select/len(data)
p_refuse = n_refuse/len(data)

plt.figure
plt.pie([p_select, p_refuse], labels=['Selected: ' + str(n_select) + '(' + str(100.*p_select) + '%)', 'Discarded: ' + str(n_refuse) + '(' + str(100.*p_refuse) + '%)'])
plt.title(folder_name + ' screened with ' + model)
plt.savefig('piePlot_summary.png', dpi=75)
plt.close()

if n_refuse > 0:
    p_refuse_Err = np.sum(data['Malfunct'] == 0)/n_refuse
    p_refuse_M = np.sum(data['5sec'] == 0)/n_refuse
    p_refuse_score = (n_refuse - np.sum(data['Malfunct'] == 0) - np.sum(data['5sec'] == 0))/n_refuse

    plt.figure
    plt.pie([p_refuse_Err, p_refuse_M, p_refuse_score], labels=[\
            'Too short: ' + str(100.*p_refuse_Err) + '%', \
            'Malfunction: ' + str(100.*p_refuse_M) + '%', \
            'Low quality: ' + str(100.*p_refuse_score) + '%'])
    plt.title(folder_name + ' screened with ' + model)
    plt.savefig('piePlot_summary_discard.png', dpi=75)
    plt.close()

final_time = time()
print("Done in {:10.1f} secs".format(final_time-init_time))

