import numpy as np
import snrutils as sn
import gc
import os

N = [1024, 2048, 4096, 8192, 16384, 32768, 65536]

try:
    os.mkdir('./KO_matrices')
except:
    print('Folder already exist')

for i in range(len(N)-1):
    M = sn.createKonnoMatrix_single(N[i+1])
    np.save('./KO_matrices/KO_' + str(N[i]) + '.npy', M)
    M = []
    gc.collect()
